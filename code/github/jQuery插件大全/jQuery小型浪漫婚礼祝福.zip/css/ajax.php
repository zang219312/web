<?php
include_once('connect.php');
$content = strip_tags($_POST['content']) ;
$query = mysql_query("insert into marry(content)values('".$content."')");
echo "insert into marry(content)values('".$content."')";


//include_once('connect.php');
//$query = mysql_query("select * from marry order by id desc limit 0, 50");
//
//while ($row = mysql_fetch_array($query)) {
//}

