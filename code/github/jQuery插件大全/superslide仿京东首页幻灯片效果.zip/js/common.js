$(function () {
    $("#banner").slide({
        titCell: "#banner-page",
        mainCell: "#index-banner",
        effect: "left",
        scroll: 1,
        vis: 1,
        autoPlay: true,
        prevCell: "#banner-page-left",
        nextCell: "#banner-page-right",
        autoPage: "<li class='slider-item'> $ </li>",
        interTime: 5000
    });
    $("#banner").hover(function () {
        $(this).find(".slider-page").show();
    }, function () {
        $(this).find(".slider-page").hide();
    })
})
