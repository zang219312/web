<?php

$targetPic = 'uploads/' . time() . ".jpg"; // 新上传图片名称

if (!empty($_FILES)) {
    $uploadInfo = $_FILES['editor_img'];
    $tempFile = $uploadInfo['tmp_name'];
    $fileTypes = array('jpg', 'jpeg', 'gif', 'png'); // 允许文件上传类型
    $fileParts = pathinfo($uploadInfo['name']);
   
    if (in_array($fileParts['extension'], $fileTypes)) {
        move_uploaded_file($tempFile, $targetPic);
       
    }
}
//$arr = array("data"=>$targetPic,"status"=>1);
//echo json_encode($arr);
 echo $targetPic;
?>