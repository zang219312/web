// JavaScript Document
$(function() {
    //问题答案点击
    function change(now) {
        $('.test .tc_wt_box').eq(now).show().find('h2').animate({
            'margin-top': '150px',
            'opacity': '1'
        },
        600,
                function() {
                    $('.test .tc_wt_box').eq(now).find('li').each(function(i) {
                        $(this).delay(i * 100).fadeIn(350);
                    });
                });
    }
    change(0);

    $('.test .tc_wt_box ul li').click(function() {
        $(this).addClass('check');
        var _index = $(this).parents('.tc_wt_box').index();
        var _next = $(this).parents('.tc_wt_box').next('.tc_wt_box');
        $(this).parents('.tc_wt_box').fadeOut(200,
                function() {
                    _next.show().find('h2').animate({
                        'margin-top': '150px',
                        'opacity': '1'
                    },
                    600,
                            function() {
                                _next.find('li').each(function(i) {
                                    $(this).delay(i * 100).fadeIn(350);
                                });
                            });
                });

        if (_index == 4) {
            //判断显示结果
            var colorStr = "";
            $('.test').find('li.check').each(function() {
                colorStr += $(this).attr('bcolor');
            });
            var _cor;
            if (colorStr.indexOf("red") != -1) {
                _cor = "red";
            } else {
                if (colorStr.indexOf("orange") != -1) {
                    _cor = "orange";
                } else {
                    if (colorStr.indexOf("yellow") != -1) {
                        _cor = "yellow";
                    } else {
                        _cor = "blue";
                    }
                }
            }
            window.location = "http://www.sucaihuo.com";
            //			if (colorStr.indexOf("red") != -1) {
            //                    $("#red").show().siblings('.tc_jg_box').hide(); 
            //                } else {
            //                    if (colorStr.indexOf("orange") != -1) {
            //                        $("#orange").show().siblings('.tc_jg_box').hide(); 
            //                    } else {
            //                        if (colorStr.indexOf("yellow") != -1) {
            //                            $("#yellow").show().siblings('.tc_jg_box').hide(); 
            //                        } else {
            //                            $("#blue").show().siblings('.tc_jg_box').hide(); 
            //                        }
            //                    }
            //            }
            //            $('.bg_an').fadeIn(100,function(){
            //            	$('.ceshi_tc_jg').show().animate({
            //					'margin-top':'-216px',
            //					'opacity':'1'
            //				},600);
            //            }); 
        }
    });
    //测试关闭
    $('.ceshi_tc_jg .close').click(function() {
        $('.ceshi_tc_jg').animate({
            'margin-top': '0px',
            'opacity': '0'
        }, 600, function() {
            change(0);
            $('.test').find('h2').css({
                'margin-top': '80px',
                'opacity': '0'
            });
            $('.test').find('li').removeClass('check').hide();
            $('.bg_an').fadeOut(100);
        });
    });
});