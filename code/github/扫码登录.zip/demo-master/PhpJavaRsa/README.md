# Java & PHP RSA 互通密钥、签名、验签、加密、解密

 [相关文档](https://blog.dbnuo.com/20191112/thio47.html)

