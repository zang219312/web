<?php

$jcarousel_items = array(
    array(
        'title' => 'Flower 1',
        'src' => 'http://www.sucaihuo.com/Public/images/other/service.jpg',
    ),

    array(
        'title' => 'Flower 2',
        'src' => 'http://www.sucaihuo.com/Public/images/other/mobile.jpg',
    ),
    array(
        'title' => 'Flower 3',
        'src' => 'http://www.sucaihuo.com/Public/images/other/mall.jpg',
    ),
    array(
        'title' => 'Flower 4',
        'src' => 'http://www.sucaihuo.com/Public/images/other/404.jpg',
    ),
    array(
        'title' => 'Flower 5',
        'src' => 'http://www.sucaihuo.com/jquery/4/443/big.jpg',
    ),
    array(
        'title' => 'Flower 6',
        'src' => 'http://www.sucaihuo.com/jquery/4/440/big.jpg',
    ),
    array(
        'title' => 'Flower 7',
        'src' => 'http://www.sucaihuo.com/jquery/4/438/big.jpg',
    ),
    array(
        'title' => 'Flower 8',
        'src' => 'http://www.sucaihuo.com/jquery/4/435/big.jpg',
    ),
    array(
        'title' => 'Flower 9',
        'src' => 'http://www.sucaihuo.com/jquery/4/433/big.jpg',
    ),
    array(
        'title' => 'Flower 10',
        'src' => 'http://www.sucaihuo.com/jquery/4/432/big.jpg',
    ),
);

/**
 * This function returns the number items. Typically, this
 * would fetch it from a database (SELECT COUNT(*) FROM items) or
 * from a directory.
 */
function jcarousel_countItems()
{
	global $jcarousel_items;

	return count($jcarousel_items);
}

/**
 * This function returns the items. Typically, this
 * would fetch it from a database (SELECT * FROM items LIMIT $limit OFFSET $offset) or
 * from a directory.
 */
function jcarousel_getItems($limit = null, $offset = null)
{
	global $jcarousel_items;

	// Copy items over
	$return = $jcarousel_items;

	if ($offset !== null) {
		$return = array_slice($return, $offset);
	}

	if ($limit !== null) {
		$return = array_slice($return, 0, $limit);
	}

	return $return;
}

?>