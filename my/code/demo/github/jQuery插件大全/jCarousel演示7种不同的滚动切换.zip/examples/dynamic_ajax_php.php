<?php

// Array indexes are 0-based, jCarousel positions are 1-based.
$first = max(0, intval($_GET['first']) - 1);
$last  = max($first + 1, intval($_GET['last']) - 1);

$length = $last - $first + 1;

// ---

$images = array(
    'http://www.sucaihuo.com/Public/images/other/service.jpg',
    'http://www.sucaihuo.com/Public/images/other/mobile.jpg',
    'http://www.sucaihuo.com/Public/images/other/mall.jpg',
    'http://www.sucaihuo.com/Public/images/other/404.jpg',
    'http://www.sucaihuo.com/jquery/4/443/big.jpg',
    'http://www.sucaihuo.com/jquery/4/440/big.jpg',
    'http://www.sucaihuo.com/jquery/4/431/big.jpg',
    'http://www.sucaihuo.com/jquery/4/435/big.jpg',
    'http://www.sucaihuo.com/jquery/4/433/big.jpg',
    'http://www.sucaihuo.com/jquery/4/432/big.jpg',
);

$total    = count($images);
$selected = array_slice($images, $first, $length);

// ---

header('Content-Type: text/xml');

echo '<data>';

// Return total number of images so the callback
// can set the size of the carousel.
echo '  <total>' . $total . '</total>';

foreach ($selected as $img) {
    echo '  <image>' . $img . '</image>';
}

echo '</data>';

?>