$(function() {
    var note = $('#note');
    var ts = (new Date("2015-10-20")).getTime();
    $('#countdown').countdown({
        timestamp: ts,
        callback: function(days, hours, minutes, seconds) {

            var message = "距离美途购网上免税店上线还有";

            message += days + "天" + (days == 1 ? '' : '') + "";
            message += hours + "小时" + (hours == 1 ? '' : '') + "";
            message += minutes + "分" + (minutes == 1 ? '' : '') + "";
            message += seconds + "秒" + (seconds == 1 ? '' : '') + "";
            message += "...";
            note.html(message);
        }
    });

});