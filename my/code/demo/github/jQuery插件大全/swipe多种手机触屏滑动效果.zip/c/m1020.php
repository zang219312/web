<?php 
//$APPID='wxba922caddc6700a8';
//$REDIRECT_URI='wx.mtgdfs.com/c/m1020.php';
//$scope='snsapi_base';
//$state = 1;
////$scope='snsapi_userinfo';//需要授权
/****
 * 1、拼成一个链接
 * 2、把链接抛出去返回一个code echo $_GET['code']
 * 3、根据code换取access_token和openid
 * 4. 使用access_token和openid来获取用户信息
 * 5、
 * 
 * 
 * 
 * 
 ***/
header("Location: https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxba922caddc6700a8&redirect_uri=http://wx.mtgdfs.com/c/m1020a.php&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect"); 

?>
