<?php

namespace Home\Controller;

use Think\Controller;

class CommonController extends Controller {

    function _initialize() {
        header("Content-type: text/html; charset=utf-8");
        $assignArr = array(
            "control" => strtolower(CONTROLLER_NAME),
            "mod" => strtolower(ACTION_NAME),
            'lang_kind' => LANG_SET,
            'time_cur' => time(),
            'url_ali' => C("url_ali"),
            "version" => C("version"),
        );
//        if (ismobile() == 0) {
            C('DEFAULT_V_LAYER', 'Mobile');
//        }
        $this->assign($assignArr);
    }

}
