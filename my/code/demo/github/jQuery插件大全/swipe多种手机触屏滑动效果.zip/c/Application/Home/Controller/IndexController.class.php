<?php

namespace Home\Controller;

use Think\Controller;

class IndexController extends CommonController {

    public function index() {
        $ads = getAds('welive_index_banner');
        $ads_index_banner = getAdsPics($ads, 'welive_index_banner',1); //轮播广告
        $this->assign('ads_index_banner', $ads_index_banner);
        $this->assign('cssArr', array("js/assets/countdown/jquery.countdown"));
        $this->assign('jsArr', array("assets/countdown/jquery.countdown","assets/js/script"));
        $this->assign('title', "首页");
          
     
        $this->display();
    }

    public function error404() {
        $this->assign('nopage', L("nopage"));
        $this->assign('jumpWords', L("merchant_detail_jump_words", array("jumpurl" => __APP__ . "/" . LANG_SET)));
        $this->error(L("merchants_no"));
    }

    public function m1020() {
        //$APPID='wxba922caddc6700a8';
        //$REDIRECT_URI='wx.mtgdfs.com/c/m1020.php';
        //$scope='snsapi_base';
        //$state = 1;
        ////$scope='snsapi_userinfo';//需要授权
        /*         * **
         * 1、拼成一个链接
         * 2、把链接抛出去返回一个code echo $_GET['code']
         * 3、根据code换取access_token和openid
         * 4. 使用access_token和openid来获取用户信息
         * 5、
         * 
         * 
         * 
         * 
         * * */
        echo 12;exit;
        header("Location: https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxba922caddc6700a8&redirect_uri=http://wx.mtgdfs.com/c/m1020a&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect");
    }

    public function m1020a() {
        //wx.mtgdfs.com/c/m1020a
        $appid = "wxba922caddc6700a8";
        $secret = "9f47a54b26ab9ed1a01fa71ae2e82f27";
        $code = I("get.code");
        $get_token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $appid . '&secret=' . $secret . '&code=' . $code . '&grant_type=authorization_code';
        $json_obj = getUrlJson($get_token_url);
        //根据openid和access_token查询用户信息 
        $access_token = $json_obj['access_token'];
        $openid = $json_obj['openid'];
        $get_user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' . $access_token . '&openid=' . $openid . '&lang=zh_CN';
        $user_obj = getUrlJson($get_user_info_url);
        $_SESSION['user'] = $user_obj;
        print_r($user_obj);
    }

}
