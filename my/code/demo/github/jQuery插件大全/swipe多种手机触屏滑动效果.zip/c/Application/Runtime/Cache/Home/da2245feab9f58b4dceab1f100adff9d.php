<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"/>
        <title><?php echo ($title); ?></title>
        <link href="<?php echo ($url_ali); ?>images/favicon.ico" rel="shortcut icon"/>
        <meta content="<?php echo (msubstr($keywords,0,3000,14000,true)); ?>" name="keywords"/>
        <meta content="<?php echo (msubstr($description,0,3000,14000,true)); ?>" name="description"/>
<!--         <link rel="stylesheet" type="text/css" href="<?php echo ($url_ali); ?>css/demo.css" />-->
        <link rel="stylesheet" type="text/css" href="<?php echo ($url_ali); ?>css/style_mobile<?php echo ($version); ?>.css" />
        <?php if(is_array($cssArr)): foreach($cssArr as $key=>$row): ?><link rel="stylesheet" type="text/css" href="<?php echo ($url_ali); ?>/<?php echo ($row); ?>.css" /><?php endforeach; endif; ?>
    </head>
    <body>
<div class='end_times'>
    <div id="countdown"></div>
    <p id="note"></p>
</div>

<!--<a class="swip_arrow">></a>

<a class="swip_arrow">></a>
<a class="swip_arrow">></a>-->
<script src="<?php echo ($url_ali); ?>js/jquery1.8.min.js" type="text/javascript"></script>
<?php if(is_array($jsArr)): foreach($jsArr as $key=>$row): ?><script src="<?php echo ($url_ali); ?>js/<?php echo ($row); ?>.js" type="text/javascript"></script><?php endforeach; endif; ?>
<script type="text/javascript" src="/c/Public/js/jquery.touchSwipe.min.js"></script>

<script type="text/javascript">
    $(function() {
        $("#test2").swipe({
            swipeStatus: function(event, phase, direction, distance, duration, fingerCount) {
//                alert("a");
            },
        });
    });
</script>
<script type="text/javascript" src="http://s0.metaostatic.com/public/metao-h5/js/metaoBase.js"/></script>

    <link rel="stylesheet" type="text/css" href="http://s0.metaostatic.com/public/metao-h5/css/view/index.css">
    <link rel="stylesheet" type="text/css" href="http://s0.metaostatic.com/public/metao-static/js/js-public/swiper/swiper.min.css">