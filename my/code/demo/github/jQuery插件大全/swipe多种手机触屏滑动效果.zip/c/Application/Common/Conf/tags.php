<?php
/**
 * Created by PhpStorm.
 * User: liufeng.bo
 * Date: 14-12-11
 * Time: 上午11:46
 */

return array(
    //配置开启多语言行为
//    'app_begin' => array('Behavior\CheckLangBehavior'),

);








?>