<?php

$lang_sel = $_GET['l'];

if (!$lang_sel) {
    $lang_sel = session('rm_selected_language');
}
if (!$lang_sel) {
    preg_match('/^([a-z\d\-]+)/i', $_SERVER['HTTP_ACCEPT_LANGUAGE'], $matches);
    $lang_sel = strtolower($matches[1]);
}
return array(
    'URL_ROUTER_ON' => true,
    'URL_ROUTE_RULES' => array(
        '/^stores$/' => 'Stores/lists',
        '/^stores\/list-([0-9-]+)$/' => 'Stores/lists?paras=:1',
        '/^stores\/([a-zA-Z0-9_ -]+)\/coupons-([0-9-]+)$/' => 'Stores/detail?name=:1&p=:2', //stores/:id\d
        '/^stores\/([a-zA-Z0-9_ -]+)$/' => 'Stores/detail?name=:1', //stores/:id\d
        '/^deals$/' => 'Deals/lists',
        '/^deals\/list-([a-zA-Z0-9-]+)$/' => 'Deals/lists?paras=:1',
        '/^deals\/([a-zA-Z0-9_ -]+)$/' => 'Deals/detail?id=:1',
        'search' => 'Search/stores_coupons',
        'thank-you' => 'Other/thanks',
        '/^local/' => 'Other/selectLang',
        '/^reg/' => 'Other/reg',
        '/^login/' => 'Other/login',
        '/^transfer/' => 'Other/transfer',
        'forget' => 'Pwd/find',
        'sendtip' => 'Pwd/send_tip',
        'error' => 'Index/error404',
        '/^index/' => 'Index/index',
        '/^promotion\/([a-zA-Z0-9_ -]+)$/' => 'Promotion/detail?name=:1',
        '/^promotions\/([a-zA-Z0-9_ -]+)$/' => 'Promotions/detail?name=:1',
    ),
    'pages' => array(
        'site_store' => '6', //商家列表页分页参数位置 必须是最末尾
        'site_coupon' => '5',
    ),
    'cachetime' => array(//设置数据缓存时间
        'getSiteInfo' => '1800', //网站相关信息 SEO
        'getStoresSelected' => '1800', //精选商家
        'getStoresDouble' => '1800', //加倍返利商家
        'getMerchantsCatsIndex' => '1800', //首页商家分类
        'getCouponCatsIndex' => '1800', //首页推荐优惠分类
        'getAllCouponsIndex' => '1800', //首页所有优惠
        'getCouponsHotIndex' => '1800', //首页热门优惠
        'getMerchantsDoubleIndex' => '1800', //首页加倍返利商家
        'getExpressIndex' => '1800', //首页转运公司
        'getMerchantsHotsRight' => '1800', //右侧热门商家
        'getUserInfo' => '36000', //根据用户id获取用户相关信息
        'getVisitedStores' => '3600', //首页和商家大全常去商家
        'getStoresLatest' => '3600', //首页右侧最新商家
    ),
    'HTML_CACHE_ON' => true, // 开启静态缓存
    'HTML_CACHE_TIME' => 3600, // 全局静态缓存有效期（秒）
    'HTML_FILE_SUFFIX' => '.html', // 设置静态缓存文件后缀
    'HTML_CACHE_RULES' => array(// 定义静态缓存规则
        // 定义格式1 数组方式
        'stores:' => array('Stores/' . $lang_sel . '/_q_{$_GET.query}k_{$_GET.keywords}n_{$_GET.name}_{$_GET.paras}_{$_GET.p}'),
        'deals:' => array('Deals/' . $lang_sel . '/_{$_GET.paras}_id_{$_GET.id}'),
        'index:' => array('Index/' . $lang_sel . '/_{:action}'),
        'promotion:' => array('Promotion/' . $lang_sel . '/{$_GET.name}'),
        'promotions:' => array('Promotions/' . $lang_sel . '/{$_GET.name}')
    ),
    'version' => "_v2.0.8", //_v2.0.7
    'url_ali' => "http://pics.rebatesme.com/newrm/", //http://www.rebatesme.com/Public/ http://pics.rebatesme.com/newrm/
    "url_service" => "http://service.rebatesme.com/rest/", //http://10.1.1.201:8080/rest/ http://service.rebatesme.com/rest/
);
