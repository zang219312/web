<?php

namespace Home\Model;

use Think\Model;

class IndexModel extends Model {

    public $tableName = "wp_users";

    public function getMerchantsHot() {//热门商家
        $s_merchants_hot = S("" . LANG_SET . "_index_merchants_hot");
        if (empty($s_merchants_hot)) {
            $data = array(
                "queryStart" => 0,
                "queryCount" => 8,
                "needCouponCount" => false,
                "startLevel" => 1,
                "endLevel" => 1,
                "misNoCouponMerchant" => false,
                "lang" => LANG_SET
            );
            $merchants = getCodeJson($data, 'getMerchantList');
            $s_merchants_hot = $merchants['merchants'];
            S("" . LANG_SET . "_index_merchants_hot", $s_merchants_hot, 1800);
        }
        return $s_merchants_hot;
    }

    public function getSiteInfo() { //网站相关信息 SEO
        $getSiteInfo = S("getSiteInfo");
        if (empty($getSiteInfo)) {
            $getSiteInfo = getCodeJson("", 'getSiteInfo');
            S("getSiteInfo", $getSiteInfo, C("cachetime.getSiteInfo"));
        }
        return $getSiteInfo;
    }

    public function getStoresSelected() {//精选商家
        $s_stores_selected = S("" . LANG_SET . "_stores_selected");
        if (empty($s_stores_selected)) {
            $data = array('startLevel' => '1', 'endLevel' => 1, 'queryCount' => '9', 'lang' => LANG_SET);
            $arr = getCodeJson($data, 'getMerchantList');
            $s_stores_selected = $arr['merchants'];
            S("" . LANG_SET . "_stores_selected", $s_stores_selected, C("cachetime.getStoresSelected"));
        }
        return $s_stores_selected;
    }

    public function getAds() {   //获取广告
        $data = array('slugs' => 'home-bbs-hot,home-bbs-notic,home-help,home-foot-help,home-right-faq,home-right-course,home-foot-more,home-sites-links,home-bbs-strategy,home-about-us,home-banner,home-slides,reg_banner,login_banner,home-nav-advertisement,home-banner-advertisement,home-right-zero-advertisement,home-right-one-advertisement,home-right-two-advertisement,home-right-three-advertisement,home-right-four-advertisement,home-right-five-advertisement,rm_stores_right0,rm_stores_right1,rm_stores_right2,rm_stores_right3,rm_stores_right4,stores-right-zero-advertisement,stores-right-one-advertisement,stores-right-two-advertisement,stores-right-three-advertisement,stores-right-four-advertisement,rm_deals_right0,rm_deals_right1,rm_deals_right2,rm_deals_right3,rm_deals_right4,deals-right-zero-advertisement,deals-right-one-advertisement,deals-right-two-advertisement,deals-right-three-advertisement,deals-right-four-advertisement,'
            . 'zhuanyun,rm_jump,rm_jump_login,globalAd', 'isOpenInNewPage' => '1', 'lang' => LANG_SET);
        $arr = getCodeJson($data, 'getAdvertiseList');
        return $arr;
    }

    public function getMerchantsCats() {//获取首页商家分类
        $cats = S("" . LANG_SET . "_index_merchants_cats");
        if (empty($cats)) {
            $data = array(
                "activitySlug" => '',
                "type" => "merchant",
                "needCouponCount" => false,
                "lang" => LANG_SET
            );
            $catsJson = getCodeJson($data, 'getCategroyList');
            $cats = $catsJson[0]['categroys'];
            if (count($cats) != 10) {
                foreach ($cats as $k => $v) {
                    if ($k > 8) {
                        $catOtherIds[] = $v['id'];
                        $catOtherSlugs[] = $v['slug'];
                        unset($cats[$k]);
                    }
                }
                if (count($cats) > 8) {
                    $cats[8]['id'] = !empty($catOtherIds) ? implode(",", $catOtherIds) : "";
                    $cats[8]['name'] = L("other");
                    $cats[8]['slug'] = "other";
                    $cats[8]['slug2'] = !empty($catOtherSlugs) ? implode(",", $catOtherSlugs) : "";
                }
            }
            S("" . LANG_SET . "_index_merchants_cats", $cats, C("cachetime.getMerchantsCatsIndex"));
        }
        return $cats;
    }

    public function getCatsMerchants($cats) {//获取商家分类对应的商家
        $s_cats = S("" . LANG_SET . "_index_cats_merchants");
        if (empty($s_cats)) {
            foreach ($cats as $k => $v) {
                // $s_merchants = S("" . LANG_SET . "_index_merchants_" . $v['slug'] . ""); //获取商品分类对应的商家

                $data = array(
                    "queryStart" => 0,
                    "queryCount" => 8,
                    "needCouponCount" => false,
                    "startLevel" => 0,
                    "endLevel" => 5,
                    "misNoCouponMerchant" => false,
                    "lang" => LANG_SET,
                    "categoryIds" => !empty($v['id']) ? $v['id'] : "",
                );
                $merchants = getCodeJson($data, 'getMerchantList');
                $s_merchants = $merchants['merchants'];
                // S("index_merchants_" . $v['slug'] . "", $s_merchants, C("cachetime.getMerchantsCatsIndex"));

                $cats[$k]['merchants'] = $s_merchants;

                // $s_coupons = S("" . LANG_SET . "_index_coupons_" . $v['slug'] . ""); //获取优惠

                $data2 = array('merchantCategorySlugs' => ($v['slug'] == 'other') ? $v['slug2'] : $v['slug'], 'queryCount' => '4', 'lang' => LANG_SET);
                $couponsJson = getCodeJson($data2, 'getCouponList');
                $s_coupons = $couponsJson['coupons'];
                S("" . LANG_SET . "_index_coupons_" . $v['slug'] . "", $s_coupons, C("cachetime.getMerchantsCatsIndex"));

                $cats[$k]['coupons'] = $s_coupons;
            }
            $s_cats = $cats;
            //S("" . LANG_SET . "_index_cats_merchants", $s_cats, C("cachetime.getMerchantsCatsIndex"));
        }
        return $s_cats;
    }

    public function getCouponCats() {//获取首页推荐优惠分类
        $s_recommed_coupon_cats = S("" . LANG_SET . "_index_recommed_coupon_cats");
        if (empty($s_recommed_coupon_cats)) {
            $data = array(
                "activitySlug" => '',
                "type" => "coupon",
                "needCouponCount" => false,
                "lang" => LANG_SET
            );
            $cats = getCodeJson($data, 'getCategroyList');
            $s_recommed_coupon_cats = $cats[0]['categroys'];
            S("" . LANG_SET . "_index_recommed_coupon_cats", $s_recommed_coupon_cats, C("cachetime.getCouponCatsIndex"));
        }
        return $s_recommed_coupon_cats;
    }

    public function getCoupons($cateId) {   //根据Category的Id来获取优惠
        if ($cateId != '') {
            $data = array('categoryId' => $cateId, 'queryCount' => '18', 'lang' => LANG_SET);
            $selectedCoupon = getCodeJson($data, 'getCouponList');
            return $selectedCoupon['coupons'];
        }
    }

    public function getAllCoupons() {   //获取所有优惠
        $s_all_coupons = S("" . LANG_SET . "_index_all_coupons");
        if (empty($s_all_coupons)) {
            $data = array('queryCount' => '18', 'startLevel' => 1, 'endLevel' => 2, 'lang' => LANG_SET);
            $selectedCoupon = getCodeJson($data, 'getCouponList');
            $s_all_coupons = $selectedCoupon['coupons'];
            S("" . LANG_SET . "_index_all_coupons", $s_all_coupons, C("cachetime.getAllCouponsIndex"));
        }
        return $s_all_coupons;
    }

    public function getMerchantsDouble() {
        if (LANG_SET == 'zh') {
            $s_data = S("" . LANG_SET . "_index_merchants_double");
            if (empty($s_data)) {
                $data = array('advertiseSlug' => 'double_rebate', 'queryCount' => '7', 'lang' => LANG_SET);
                $arr = getCodeJson($data, 'getMerchantList');
                $s_data = $arr['merchants'];
                S("" . LANG_SET . "_index_merchants_double", $s_data, C("cachetime.getMerchantsDoubleIndex"));
            }
            return $s_data;
        }
    }

    public function getCouponsHot() { //首页热门优惠
        $s_data = S("" . LANG_SET . "_index_hot_coupons");
        if (empty($s_data)) {
            $data = array('hotMerchant' => true, 'queryCount' => '4', 'lang' => LANG_SET);
            $couponsJson = getCodeJson($data, 'getCouponList');
            $s_data = $couponsJson['coupons'];
            S("" . LANG_SET . "_index_hot_coupons", $s_data, C("cachetime.getCouponsHotIndex"));
        }
        return $s_data;
    }

    public function getMerchantsMy() { //首页右侧商家
        $userinfo = getUserId();
        $s_uid = $userinfo['uid'];
        if (intval($s_uid) > 0) {

            $cache_name = "stores_visied_" . $s_uid . "_" . LANG_SET;
            $stores_visied = S($cache_name);

            if (empty($stores_visied)) {
                $chid_left_my_stores = "rm-home-rightvis-mer"; //左侧我的商家 chid
                $data = array('userId' => $s_uid, 'queryCount' => 48, "needCouponCount" => true, 'lang' => LANG_SET);
                $arr = getCodeJson($data, 'getBusyMerchantListByUserId');
                $totalCount = $arr['totalCount'];
                $other = $totalCount % 8;
                $page = ceil($totalCount / 8);
                $lists = $arr['merchants'];
                $li = '';
                foreach ($lists as $k => $v) {
                    $cla = "";
                    if ($k % 2 == 1) {
                        $cla = 'even';
                    }
                    if ($k % 8 == 0) {
                        $li .= "<li><div class='div_often_stores clearfix'>";
                    }
                    $li .= "<div class='div_often_per " . $cla . "' data-type='1'  data-coupon-url='" . getCouponUrl($v['rebateUrl'], $chid_left_my_stores, $v['id']) . "' data-coupon-count='" . $v['couponCount'] . "'
                    >
<a href = '" . __APP__ . "/stores/" . $v['urlName'] . "' target = '_blank' class='often_name_url'>
<img src = '" . $v['logo'] . "' alt = '" . $v['name'] . "' />
</a>
<a class='num' href = '" . __APP__ . "/stores/" . $v['urlName'] . "' target = '_blank'>
<span class='num-only' data-rebate-range='" . getRebate($v['rateRanged']) . "'>" . $v['commission'] . "</span>%
</a>
</div>";
                    if ($k % 8 == 7) {
                        $li .= "</div></li>";
                    }
                    if ($other == $k && $other != 7 && ceil($k / 8) == $page) {
                        $li .= "</div></li>";
                    }
                }
                $stores_visied = $li;
                S($cache_name, $stores_visied, C("cachetime.getVisitedStores"));
            }
            return $stores_visied;
        }
    }

    public function getAdsPics($ads, $slug) {
        if ($ads['adGroups']) {
            $ads_pics = $ads['adGroups'][$slug]['advertises'];
            foreach ($ads_pics as $k => $v) {
                preg_match_all("/<img.*src\s*=\s*[\"|\']?\s*([^>\"\'\s]*)/i", $v['content'], $imgs);
                $ads_pics[$k]['pic'] = $imgs[1][0];
            }
            return $ads_pics;
        }
    }

    public function getExpress() {//热门转运公司
        $s_express = S("index_express");
        if (empty($s_express)) {
            $s_express = getUrlJson("http://zhuanyun.rebatesme.com/Index/getJsonIndexExpress/num/6");
            S("index_express", $s_express, C("cachetime.getExpressIndex"));
        }
        return $s_express;
    }

    public function getExpressCompany($id) {//根据转运公司Id获取热门转运公司
        $s_express = getUrlJson("http://zhuanyun.rebatesme.com/Index/getJsonIndexExpressByCompanyId/companyId/$id");
        return $s_express;
    }

    public function getMerchantsByCountry() { //首页国家获取
        $s_data = S("" . LANG_SET . "_index_country");
        if (empty($s_data)) {
            $data = array('queryStart' => 0, 'queryCount' => '2', 'lang' => LANG_SET);
            $s_data = getCodeJson($data, 'getCountryList');
            S("" . LANG_SET . "_index_country", $s_data, C("cachetime.getCouponsHotIndex"));
        }
        return $s_data;
    }

    public function getStoresBycountry($countryId) { //根据国家Id获取下面的商家
        foreach ($countryId as $k => $v) {
            $data = array('queryStart' => 0, 'queryCount' => '8', 'countryId' => intval($v['id']), 'lang' => LANG_SET);
            $s_data[$v['name']] = getCodeJson($data, 'getMerchantList');
        }
        return $s_data;
    }
    public function getStoresLatest() {//最新商家
        $s_stores_latest = S("" . LANG_SET . "_stores_latest");
        if (empty($s_stores_latest)) {
            $data = array('startLevel' => '0', 'endLevel' => 5,'orderType'=> 4, 'queryCount' => '6', 'lang' => LANG_SET);
            $arr = getCodeJson($data, 'getMerchantList');
            $s_stores_latest = $arr['merchants'];
            S("" . LANG_SET . "_stores_latest", $s_stores_latest, C("cachetime.getStoresLatest"));
        }
        return $s_stores_latest;
    }
    /*获取排行榜数据*/
    public function getSlugFromPosition($position){
        $data = array(
            'position' => $position,
        );
        $getChartData = getCodeJson($data, 'getSiteItemList');
        return $getChartData;
    }
}
?>

