<?php

function getArrayField($id, $arr, $field = 'name') {

    if ($id > 0) {
        if ($field != '') {
            foreach ($arr as $v) {
                if ($v['id'] == $id) {
                    return $v[$field];
                    break;
                }
            }
        } else {
            return $arr[$id];
        }
    }
}

function getArrayOne($id, $arr) {
    if ($id > 0) {
        foreach ($arr as $k => $v) {
            if ($k == $id) {
                return $v;
                break;
            }
        }
    }
}

function getUrlJson($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    $lists = json_decode($output, true);
    return $lists;
}

/**
 * 获取当前页面完整URL地址
 */
function get_url() {
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : $path_info);
    $relate_url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
    return urlencode($relate_url);
}

function getAds($slugs) {   //获取广告
    $data = array('slugs' => $slugs, 'isOpenInNewPage' => '1', 'lang' => 'zh');
    $arr = getCodeJson($data, 'getAdvertiseList');
    return $arr;
}

function getAdsPics($ads, $slug, $bg = '') {
    if ($ads['adGroups']) {
        $ads_pics = $ads['adGroups'][$slug]['advertises'];
        foreach ($ads_pics as $k => $v) {
            preg_match_all("/<img.*src\s*=\s*[\"|\']?\s*([^>\"\'\s]*)/i", $v['content'], $imgs);
            if ($bg == 1) {
                preg_match_all("/<img.*src\s*=\s*[\"|\']?\s*([^>\"\'\s]*)/i", $v['background'], $imgs2);
                $ads_pics[$k]['bg'] = replaceMtgdfs($imgs2[1][0]);
            }
            $ads_pics[$k]['pic'] = replaceMtgdfs($imgs[1][0]);
        }
        return $ads_pics;
    }
}

function replaceMtgdfs($pic) {
    return str_replace("rebatesme", "mtgdfs", $pic);
}

function getCodeJson($data, $func, $site_code = "rebatesme", $mtype = "") {
    $site_code = $site_code ? $site_code : "rebatesme";
    $key = getSiteKey($site_code);

    $data_json = json_encode($data, JSON_UNESCAPED_SLASHES);
    $beforeCheck = $site_code . $data_json . $key;
    $check_code = md5($beforeCheck);
    if ($mtype == 2) {
        $url_func = "user";
    } elseif ($mtype == 3) {
        $url_func = "msg";
    } else {
        $url_func = "coupon";
    }
    $url = "http://service.mtgdfs.com/mtgservice/rest/" . $url_func . "/" . $func . "?siteCode=" . $site_code . "&data=" . urlencode($data_json) . "&checkCode=" . $check_code . "";
    if ($func == 'sendMessage') {
        //echo $url;exit;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    $lists = json_decode($output, true);
    return $lists;
}

function getSiteKey($site_code) {
    $site_key = "950eb1c9c6395a1a24cf7032dc8dec3d";
    switch ($site_code) {
        case "zhuanyun":
            $site_key = "2451589652WDESRFTG25GTFR562356ED";
            break;
    }
    return $site_key;
}

function is_mobile() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $mobile_agents = array("240x320", "acer", "acoon", "acs-", "abacho", "ahong", "airness", "alcatel", "amoi",
        "android", "anywhereyougo.com", "applewebkit/525", "applewebkit/532", "asus", "audio",
        "au-mic", "avantogo", "becker", "benq", "bilbo", "bird", "blackberry", "blazer", "bleu",
        "cdm-", "compal", "coolpad", "danger", "dbtel", "dopod", "elaine", "eric", "etouch", "fly ",
        "fly_", "fly-", "go.web", "goodaccess", "gradiente", "grundig", "haier", "hedy", "hitachi",
        "htc", "huawei", "hutchison", "inno", "ipad", "ipaq", "iphone", "ipod", "jbrowser", "kddi",
        "kgt", "kwc", "lenovo", "lg ", "lg2", "lg3", "lg4", "lg5", "lg7", "lg8", "lg9", "lg-", "lge-", "lge9", "longcos", "maemo",
        "mercator", "meridian", "micromax", "midp", "mini", "mitsu", "mmm", "mmp", "mobi", "mot-",
        "moto", "nec-", "netfront", "newgen", "nexian", "nf-browser", "nintendo", "nitro", "nokia",
        "nook", "novarra", "obigo", "palm", "panasonic", "pantech", "philips", "phone", "pg-",
        "playstation", "pocket", "pt-", "qc-", "qtek", "rover", "sagem", "sama", "samu", "sanyo",
        "samsung", "sch-", "scooter", "sec-", "sendo", "sgh-", "sharp", "siemens", "sie-", "softbank",
        "sony", "spice", "sprint", "spv", "symbian", "tablet", "talkabout", "tcl-", "teleca", "telit",
        "tianyu", "tim-", "toshiba", "tsm", "up.browser", "utec", "utstar", "verykool", "virgin",
        "vk-", "voda", "voxtel", "vx", "wap", "wellco", "wig browser", "wii", "windows ce",
        "wireless", "xda", "xde", "zte");
    $is_mobile = 0;
    foreach ($mobile_agents as $device) {
        if (stristr($user_agent, $device)) {
            $is_mobile = 1;
            break;
        }
    }
    return $is_mobile;
}

function ismobile() {
    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
    if (isset($_SERVER['HTTP_X_WAP_PROFILE']))
        return 1;

    //此条摘自TPM智能切换模板引擎，适合TPM开发
    if (isset($_SERVER['HTTP_CLIENT']) && 'PhoneClient' == $_SERVER['HTTP_CLIENT'])
        return 1;
    //如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
    if (isset($_SERVER['HTTP_VIA']))
    //找不到为flase,否则为true
        return stristr($_SERVER['HTTP_VIA'], 'wap') ? 1 : 0;
    //判断手机发送的客户端标志,兼容性有待提高
    if (isset($_SERVER['HTTP_USER_AGENT'])) {
        $clientkeywords = array(
            'nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-', 'philips', 'panasonic', 'alcatel', 'lenovo', 'iphone', 'ipod', 'blackberry', 'meizu', 'android', 'netfront', 'symbian', 'ucweb', 'windowsce', 'palm', 'operamini', 'operamobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 'mobile'
        );
        //从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
            return 1;
        }
    }
    //协议法，因为有可能不准确，放到最后判断
    if (isset($_SERVER['HTTP_ACCEPT'])) {
        // 如果只支持wml并且不支持html那一定是移动设备
        // 如果支持wml和html但是wml在html之前则是移动设备
        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
            return 0;
        }
    }
    return 0;
}
