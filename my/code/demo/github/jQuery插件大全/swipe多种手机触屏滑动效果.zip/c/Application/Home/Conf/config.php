<?php

$lang_sel = $_GET['l'];

if (!$lang_sel) {
    $lang_sel = session('rm_selected_language');
}
if (!$lang_sel) {
    preg_match('/^([a-z\d\-]+)/i', $_SERVER['HTTP_ACCEPT_LANGUAGE'], $matches);
    $lang_sel = strtolower($matches[1]);
}

return array(
    'URL_ROUTER_ON' => true,
    'URL_ROUTE_RULES' => array(
        '/^m1020/' => 'Index/m1020',
    ),
    'pages' => array(
        'site_store' => '6', //商家列表页分页参数位置 必须是最末尾
        'site_coupon' => '5',
    ),
    'cachetime' => array(//设置数据缓存时间
        'getSiteInfo' => '1800', //网站相关信息 SEO
    ),
    'HTML_CACHE_ON' => false, // 开启静态缓存
    'HTML_CACHE_TIME' => 3600, // 全局静态缓存有效期（秒）
    'HTML_FILE_SUFFIX' => '.html', // 设置静态缓存文件后缀
    'HTML_CACHE_RULES' => array(// 定义静态缓存规则
        // 定义格式1 数组方式
        'stores:' => array('Stores/' . $lang_sel . '/_q_{$_GET.query}k_{$_GET.keywords}n_{$_GET.name}_{$_GET.paras}_{$_GET.p}'),
    ),
    'version' => "", //_v2.0.8
    'url_ali' => "http://wx.mtgdfs.com/c/Public/", //http://wx.mtgdfs.com/c/Public/ http://pics.rebatesme.com/newrm/  
    "url_service" => "http://service.rebatesme.com/rest/", //http://10.1.1.201:8080/rest/ http://service.rebatesme.com/rest/
);
