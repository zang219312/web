<?php

namespace Home\Controller;

use Think\Controller;

class RestfulController extends Controller {

    public function getSearch() {//公共搜索
        $keyword = I('get.keyword');
        $data = array('keywords' => $keyword, 'lang' => LANG_SET, "queryCount" => 16);
        $store = getCodeJson($data, 'getSimpleMerchantList');
        $merchants = $store['merchants'];
        if ($merchants) {
            foreach ($merchants as $k => $v) {
                $merchants[$k]['rateRanged'] = getRebate($v['rateRanged']);
            }
        }
        echo json_encode(array("stores" => $merchants));
    }

    public function isHasLogin() {
        $s_uid = session("unionUid");
        $s_email = session("unionEmail");
        if (empty($s_uid) or empty($s_email)) {
            $c_uid = cookie("unionUid");
            $c_checkcode = cookie("unionCheckcode");
            if (!empty($c_uid) && !empty($c_checkcode)) {
                if ($c_checkcode == getUnionLoginCheckcode($c_uid)) {
                    $data = array(
                        "userId" => $c_uid,
                    );
                    $userinfo = getCodeJson($data, 'getSiteUserInfo', '', '2');
                    $s_email = $userinfo['userEmail'];
                    session("unionUid", $c_uid);
                    session("unionEmail", $s_email);
                } else {
                    $c_uid = '';
                }
            }
            $s_uid = $c_uid;
        }
        echo $s_uid;
    }

    public function isLoginState() { //判断是否登录
        $userinfo = getUserId();
        $s_uid = $userinfo['uid'];
        $s_email = $userinfo['email'];

        $arr = array(
            "uid" => $s_uid,
            "email" => $s_email
        );

        if (intval($s_uid) > 0 && I("get.is_merchant_my") == 1) {//我的商家
            $indexModal = new \Home\Model\IndexModel();

            $arr['merchants_my'] = $indexModal->getMerchantsMy();
        }
        if ($s_uid > 0) {
            $data = array(
                "queryStart" => 0,
                "queryCount" => 3,
                "userId" => $s_uid,
                "activitySlug" => '',
                "lang" => LANG_SET
            );
            $order_info = getCodeJson($data, 'getUserOrderInfo');
            $li_order = '';
            if ($order_info['orders']) {
                foreach ($order_info['orders'] as $k => $v) {
                    if ($v['useableDay'] == 0) {
                        $recharge_days_tip = L("withdraw_available");
                    } else {
                        $recharge_days_tip = L("days_withdraw", array("days" => $v['useableDay']));
                    }
                    if (LANG_SET == 'zh') {
                        $help = "<a class='rebate-btn button' href='http://www.rebatesme.com/" . LANG_SET . "/ex-rebates/' target='_blank'>" . L("rebate_no_wait") . "</a>";
                    }
                    $li_order .= "<li class='" . getEqual($k, 2, "bordernone") . "'><div class='order-merchant'>
<span class='order-time'>" . L("order_time") . "：" . $v['orderDate'] . "</span>
<span class='merchant-name'>" . $v['merchantName'] . "</span></div>
<div class='order-info'><span class='rebate-money'>" . L("rebate_word") . "：<span class='orange'>$" . $v['commission'] . "</span></span>
<span class='recharge-days'>" . $recharge_days_tip . "</span>
" . $help . "</div></li>";
                }
            }
            $arr['li_order'] = $li_order;
            $arr['disableUse'] = getDecimal($order_info['disableUse']);
            $arr['ableUse'] = getDecimal($order_info['ableUse']);
            $arr['total'] = $order_info['total']; //订单数量
            $arr['login_first'] = session("login_first");
            if (session("login_first") == 1) {
                session("login_first", 0);
            }
        }
        echo json_encode($arr);
    }

    public function select_lang() {//选择语言
        $url = I('get.urlbylang');
        header("location:$url");
    }

    public function getStoresVisiedPage() {//获取访问过的商家
        $rightSidebarModel = new \Home\Model\RightsidebarModel();
        echo $rightSidebarModel->getStoresVisied(1); //常去商家
    }

    public function logout() {
        session('unionUid', null);
        session('unionEmail', null);
        setcookie("unionUid", "", time() - 360000, '/', 'rebatesme.com', false);
        setcookie("unionCheckcode", "", time() - 360000, '/', 'rebatesme.com', false);
        setcookie("myuid", "", time() - 360000, '/', 'rebatesme.com', false);
        setcookie("myemail", "", time() - 360000, '/', 'rebatesme.com', false);
        setcookie('cookie_user_id', "", time() + 60 * 60 * 24 * 30000000, '', 'rebatesme.com', false); //300天
        $r = $_GET['r'] ? $_GET['r'] : __APP__;
        header("Location: " . $r . "");
    }

    public function getCouponMerchants() {

        $dealsModal = new \Home\Model\DealsModel();
        $alpha = I("get.alpha");
        $keyword = I("get.keyword");
        $count = 1000;
        if ($alpha == 'hot') {
            $count = 60;
        }
        $compact = compact('alpha', 'keyword', 'count');

        $merchants = $dealsModal->getMerchantsByName($compact); //getSimpleMerchantList
//        print_r($merchants);
        $pathname = I("get.pathname");
        $pathArr = explode("list-", $pathname);
        if (count($pathArr) > 1) {
            $path = $pathArr[1];
        } else {
            $path = getParamZero(C("pages.site_coupon"));
        }

        $li = "";
        $site_id = 3;
        $site_alpha = 4;
        $pathExplode = explode("-", $path);
//        print_r($merchants);
        foreach ($merchants as $v) {
            $pathExplode[$site_id] = $v['id'];
//            $pathExplode[$site_alpha] = ($alpha == '0-9') ? "num" : $alpha;
            $pathExplode[$site_alpha] = strtoupper($v['prefix']);
            $url_param = implode("-", $pathExplode);
            if ($alpha == 'hot') {
                $li .= "<li><a href='" . __APP__ . "/deals/list-" . $url_param . "#coupon_search'>" . $v['name'] . "</a></li>";
            } else {
                $li .= "<li><a href='" . __APP__ . "/deals/list-" . $url_param . "#coupon_search'>" . $v['name'] . "</a></li>";
            }
        }
        echo $li;
    }

    public function getUserInfo() { //http://www.rebatesme.com/Restful/getUserInfo
        $userid = I("get.userid", 0, 'int');

        if ($userid > 0) {
            $userinfo = S("userinfo_" . $userid . "");
            if (empty($userinfo)) {
                $data = array(
                    "userId" => $userid,
                );
                $userinfo = getUnionJson($data, 'getSiteUserInfo', '', '2');
                S("userinfo_" . $userid . "", $userinfo, C("cachetime.getUserInfo"));
            }
            echo json_encode($userinfo);
        }
    }

    public function getVersion() { //获取版本号
        $arr = array(
            'version' => C("version"),
            "url_ali" => C("url_ali")
        );
        echo json_encode($arr);
    }

    public function subSuggest() {
        $userInfo = getUserId();
        $data['userId'] = $userInfo['uid']>0?$userInfo['uid']:"";
        $data['resultEmail'] = I("post.email");
        $data['resultQQ'] = I("post.qq");
        $data['msg'] = I("post.content");
        $data['typeIds'] = I("post.typeIds") ? substr(I("post.typeIds"), 0, -1) : "";
        $rs = getUnionJson($data, 'saveSuggestion', '', '5');
        echo json_encode($rs);
    }

}

?>