<?php
$id=$_GET['id'];
if($id==1){
	echo '加载成功！';
}
?>