<?php

echo 1;//短信发送成功
